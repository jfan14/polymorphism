package subclass;
import superclass.A;
public class C extends A{
	public double c;
	
	public C() {
		c = 0.0;
		System.out.println("Default constructor of class C");
	}
	
	public C(int new_a, double new_aa, double new_c) {
		super(new_a,new_aa);
		this.setC(new_c);
	}
	
	public double getC() {
		return this.c;
	}
	
	public void setC(double c) {
		this.c = c;
	}
	
	public String toString() {
		return super.toString();
	}
	
	public int m1() {
		int i2 = a + (int)(c/2);
		System.out.println("m1 implementation of C is executing now");
		return i2;
	}
}
