package client;
import subclass.B;
import subclass.C;
import superclass.A;
import subclass.D;
public class Client {
	public static void main(String [] args) {
		B objB = new B();
		C objC = new C();
		A objA;
		objA = objB;
		objA.m1();
		objA = objC;
		objA.m1();
		
		
		System.out.println("\n");
		
		D objD = new D();
		objC = objD;
		objA = objC;
		objA.m3();
		
		System.out.println("\n");
		
		objD.m2('e');
		objD.m2('h');
	}
}
