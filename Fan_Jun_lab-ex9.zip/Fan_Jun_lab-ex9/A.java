package superclass;
public abstract class A {
	public int a;
	private double aa;
	
	public A() {
		a = 0;
		aa = 0.0;
		System.out.println("Default constructor of class A");
	}	
	public A(int new_a, double new_aa) {
		this.setA(new_a);
		this.setAa(new_aa);
	}
	
	public int getA() {
		return this.a;
	}
	
	public void setA(int a) {
		this.a = a;
	}
	
	public double getAa() {
		return this.aa;
	}
	
	public void setAa(double aa) {
		this.aa = aa;
	}
	
	public int m2(char a) {
		int x = (int) a;
		System.out.println("m2 of A is executing now");
		return x;
	}
	
	public int m2(int x1) {
		int y = 10 + x1;
		System.out.println("second version of m2 in A is executing now");
		return y;
	}
	
	public void m3() {
		System.out.println("m3 of A is executing now");
	}
	public String toString() {
		return " ";
	}
	
	public abstract int m1();
	
}
