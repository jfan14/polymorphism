package subclass;
import superclass.A;
public class B extends A{
	public String s;
	
	public B() {
		super();
		s = "test";
		System.out.println("Default constructor of class B");
	}
	
	public B(int new_a, double new_aa, String new_s) {
		super(new_a, new_aa);
		this.setS(new_s);
	}
	
	public String getS() {
		return this.s;
	}
	
	public void setS(String s) {
		this.s = s;
	}
	
	public String toString() {
		return super.toString();
	}
	
	public int m1() {
		int aa = (int)super.getAa();
		int i1 = 5*a + (int)aa;
		System.out.println("m1 implementation of B is executing now");
		return i1;
	}
}
