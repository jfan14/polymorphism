package subclass;
import superclass.Loan;
import subclass.LoanConstants;
public class BusinessLoan extends Loan{
	public double loanRate = 0.01;
	
	public BusinessLoan() {
		loanRate = 0.01;
	}
	
	public BusinessLoan(String new_lName, double new_amount, int new_term) {
		super(new_lName, new_amount, new_term);
	}
	
	public String toString() {
		String ret;
		ret = super.toString() + "\n" + "Loan rate is: " + this.loanRate;
		return ret;
	}
	
}
