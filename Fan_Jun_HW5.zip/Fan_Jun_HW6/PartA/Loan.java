package superclass;
import subclass.LoanConstants;
public abstract class Loan implements LoanConstants{
	private int loanNum;
	private String lName;
	private double amount;
	//private double interest;
	private int term;
	private static int uniqueID = 10000;
	
	public Loan() {
		loanNum = uniqueID;
		uniqueID++;
		lName = "";
		amount = 0;
		//interest = 0.0;
		term = 0;
		
		
	}
	
	public Loan(String new_lName, double new_amount, int new_term) {
		loanNum = uniqueID;
		uniqueID++;
		this.setLName(new_lName);
		this.setAmount(new_amount);
		this.setTerm(new_term);
	}
	
	public String getLName() {
		return this.lName;
	}
	
	public void setLName(String lName) {
		this.lName = lName;
	}
	
	public double getAmount() {
		return this.amount;
	}
	
	public void setAmount(double amount) {
		if(amount <= maxLoan)
			this.amount = amount;
		else
			this.amount = maxLoan;
	}
	
	public int getTerm() {
		return this.term;
	}
	
	public void setTerm(int term) {
		if(term != shortTerm && term != mediumTerm && term != longTerm)
			this.term = 1;
		else
			this.term = term;
	}
	
	public String toString() {
		String ret;
		ret = "Loan ID: " + this.loanNum + "\t" + "Last Name: " + this.lName + "\t" + "Loan amount: " + this.amount + "\t" + "Loan term: " + this.term + "\n";
		return ret;
	}
}
