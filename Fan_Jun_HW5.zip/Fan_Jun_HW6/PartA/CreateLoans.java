package client;
import subclass.BusinessLoan;
import subclass.PersonalLoan;
import subclass.LoanConstants;
import java.util.*;
import java.util.Vector;
public class CreateLoans implements LoanConstants {
	
	public static double calculator(int time, double amount, double rate) {
		double finalAmount = amount+(amount * rate * time);
		return finalAmount;
	}
	
	
	public static void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		Scanner scan1 = new Scanner(System.in);
		String input;
		String lastName, lastName2;
		double loanAmount, loanAmount2;
		int year, year2;
		BusinessLoan bl;
		PersonalLoan pl;
		Vector <BusinessLoan> info = new Vector<BusinessLoan>();
		Vector <PersonalLoan> info2 = new Vector<PersonalLoan>();
		System.out.println("Thank you for visiting " + companyName);
		System.out.println("Our Business Loan interest rate is 1%");
		System.out.println("Our personal loan interest rate is 2%");
		
		System.out.println("Now let's start choosing the loan for you");
		String option = " ";
		while(option!="Q") {
			System.out.println("Please enter the loan type(type B for business loan, P for personal loan, Q for quit): ");
			option = scan.nextLine();
			
			switch(option) {
				case"B":
				case"b":
					System.out.println("Enter your last name: ");
					lastName = scan.next();
					System.out.println("What is the loan amount you expected: ");
					loanAmount = scan.nextDouble();
					System.out.println("How long you are going to loan(in terms of years): ");
					year = scan.nextInt();
					bl = new BusinessLoan(lastName, loanAmount, year);
					info.addElement(bl);
					for(int i = 0; i < info.size(); i++) {
						System.out.println(info.get(i).toString());
						System.out.println("Your total due after interest is: "+ calculator(info.get(i).getTerm(), info.get(i).getAmount(), bl.loanRate));
					}
					scan.nextLine();
					break;
					
				case"P":
				case"p":
					System.out.println("Enter your last name: ");
					lastName2 = scan.next();
					System.out.println("What is the loan amount you expected: ");
					loanAmount2 = scan.nextDouble();
					System.out.println("How long you are going to loan(in terms of years): ");
					year2 = scan.nextInt();
					pl = new PersonalLoan(lastName2, loanAmount2, year2);
					info2.addElement(pl);
					for(int k = 0; k < info2.size() ; k++) {
						System.out.println(info2.get(k).toString());
						System.out.println("Your total due after interest is: "+ CreateLoans.calculator(info2.get(k).getTerm(), info2.get(k).getAmount(), pl.loanRate));
					} 
					scan.nextLine();
					break;
					
				case"Q":
				case"q":
						System.out.println("Quitting application");
						System.exit(0);
					break;
					
				default:
					System.out.println("Something went wrong please try again");
					break;
			}
		}
	}
}
