package client;
import superclass.CardGame;
import subclass.Bridge;
import subclass.Poker;
public class PlayCardGames {
	public static void main(String [] args) {
		Poker p = new Poker();
		Bridge b = new Bridge();
		
		System.out.println(b.displayDescription());
		b.deal();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println(p.displayDescription());
		p.deal();
	}
}
