package subclass;
import superclass.CardGame;
public class Bridge extends CardGame{
	public int cardNum = 13;
	
	public String displayDescription() {
		String ret;
		ret = "General descriptions:\n \nThe cards are shuffled by the player to dealer's left and cut by the player to dealer's right."
				+ "\nThe dealer deals out all the cards one at a time so that each player has 13. Turn to deal rotates clockwise."
				+ "\nIt is traditional to use two packs of cards. During each deal, the dealer's partner shuffles the other pack and places it to the right. "
				+ "\nThe dealer for the next hand then simply needs to pick up the cards from the left and pass them across to the right to be cut. "
				+ "\nProvided all the players understand and operate it, this procedure saves time and helps to remember whose turn it is to deal, "
				+ "\nas the spare pack of cards is always to the left of the next dealer.\n"
				+"\nHere are your "+cardNum+" cards\n";
		return ret;
	}

	
	public void deal() {
		super.shuffle();
		for(int i=0;i<cardNum;i++) {
			System.out.println(CardGame.deck[i]);
		}
		
	}
	
}
