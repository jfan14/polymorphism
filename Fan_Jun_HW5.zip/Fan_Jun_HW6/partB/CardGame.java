package superclass;
import subclass.Card;
public abstract class CardGame {
	public static String [] deck = new String[52];
	
	public CardGame() {
		int counter = 0;
		for(int i=0;i<Card.suit.length;i++) {
			for(int j=0;j<Card.value.length;j++) {
				deck[counter] = Card.suit[i] +" of "+ Card.value[j];
				counter++;
			}
		}
	}
	
	
	public void shuffle() {
		int rndVal;
		int range = 52;
		for(int i=0; i<deck.length;i++) {
			rndVal = (int)(Math.random()*(range-1)+1);
			deck[rndVal] = deck[i];
		}
	}
	
	public abstract String displayDescription();
	public abstract void deal();
}
