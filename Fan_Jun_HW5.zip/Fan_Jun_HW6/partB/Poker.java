package subclass;

import superclass.CardGame;

public class Poker extends CardGame {
	public int cardNum = 5;

	public String displayDescription() {
		String ret;
		ret = "General Description: \n"+
				"\n1. Royal Flush: The best possible hand in Texas hold em is the combination of ten, jack, queen, king, ace, all of the same suit"+
				"\n2. Straight Flush: Five cards of the same suit in sequential order"+
				"\n3. Four Of A Kind: Any four numerically matching cards"+
				"\n4. Full House: Combination of three of a kind and a pair in the same hand"+
				"\n5. Flush: Five cards of the same suit, in any order"+
				"\n6. Straight: Five cards of any suit, in sequential order"+
				"\n7. Three Of A Kind: Any three numerically matching cards"+
				"\n8. Two Pair: Two different pairs in the same hand"+
				"\n9. One Pair: Any two numerically matching cards"+
				"\n10. High Card: The highest ranked card in your hand with an ace being the highest and two being the lowest\n"+
				"\nHere are your "+cardNum+" cards\n";

;
		return ret;
	}

	public void deal() {
		super.shuffle();
		for (int i = 0; i < cardNum; i++) {
			System.out.println(CardGame.deck[i]);
		}

	}

}
