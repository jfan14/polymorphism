package subclass;
public class Card{
	public static String [] suit = {"SPADE","HEART","CLUB","DIAMOND"};
	public static String [] value = {"ACE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE","TEN","JACK","QUEEN","KING"};
}
