package client;
import subclass.Sphere;
import subclass.Cylinder;
import superclass.Circle;
public class CylinderSphereClient {
	public static void main(String [] args){
	
	Cylinder cy1 = new Cylinder(28,35);
	System.out.println(cy1.toString());
	
	Sphere s1 = new Sphere(6);
	System.out.println(s1.toString());
	
	Circle c1 = new Circle(5);
	System.out.println(c1.toString());
	
	c1 = (Circle)cy1;
	System.out.println(c1.toString());
	
	c1 = (Circle) s1;
	System.out.println(c1.toString());
	
	Circle [] c = new Circle[3];
	Circle c2 = new Circle(3);
	c[0] = c2;
	Cylinder cy3 = new Cylinder(10,20);
	c[1] = cy3;
	Sphere s3 = new Sphere(3);
	c[2] = s3;
	
	for(int i=0;i<c.length;i++) {
		System.out.println(c[i].toString());
	}
	}
}