package client;
import subclass.Sphere;
import subclass.Cylinder;
import superclass.CircleVolume;
public class CylinderSphereClient {
	public static void main(String [] args){
		Cylinder cy1 = new Cylinder(5,10);
		Sphere s1 = new Sphere(5);
		System.out.println(cy1.toString());
		System.out.println(s1.toString());
		
		CircleVolume c1 = (CircleVolume)cy1;
		CircleVolume c2 = (CircleVolume)s1;
		System.out.println(c1.calcArea());
		System.out.println(c1.calcCircumference());
		System.out.println(c1.getVolume());
		
		System.out.println(c2.calcArea());
		System.out.println(c2.calcCircumference());
		System.out.println(c2.getVolume());
		
		Sphere s2 = new Sphere(6);
		Cylinder cy2 = new Cylinder(5,8);
		
		CircleVolume [] cv = new CircleVolume[4];
		cv[0] = c1;
		cv[1] = c2;
		cv[2] = s2;
		cv[3] = cy2;
		
		for(int i=0;i<cv.length;i++) {
			System.out.println(cv[i].toString());
		}
	}
}