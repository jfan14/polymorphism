package subclass;
import superclass.CircleVolume;
public class Sphere extends CircleVolume{
	
	public Sphere() {
		super(0);
	}
	
	public Sphere(double new_radius) {
		super(new_radius);
	}
	
	public Sphere(CircleVolume new_c) {
		super(new_c.getRadius());
	}
	
	public float getVolume() {
		float sphereVolume;
		sphereVolume = (float) ((4 * Math.PI * Math.pow(3, getRadius()))/3);
		return sphereVolume;
	}
	
	public String toString() {
		String ret;
		ret = super.toString();
		ret = ret + "\nSphere Volume: " + this.getVolume();
		return ret;
	}
}
