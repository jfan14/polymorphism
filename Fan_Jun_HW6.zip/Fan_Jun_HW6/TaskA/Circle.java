package superclass;
public class Circle {
	private double radius;
	
	public Circle() {
		radius = 0;
	}
	
	public Circle(double new_radius) {
		this.setRadius(new_radius);
	}
	
	public double getRadius() {
		return this.radius;
	}
	
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	public double calcArea() {
		double area;
		area = (this.radius * this.radius * Math.PI);
		return area;
	}
	
	public double calcCircumference() {
		double circumference;
		circumference = 2 * Math.PI * this.radius;
		return circumference;
	}
	
	public String toString() {
		String ret;
		ret = "\nRadius: " + this.radius;
		ret = ret + "\n" + "Area: " + this.calcArea();
		ret = ret + "\n" + "Circumference: " + this.calcCircumference();
		return ret;
	}
}
