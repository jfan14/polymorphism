package client;
import subclass.Cylinder;
import superclass.Circle;
public class CylinderClient {
	public static void main(String [] args) {
		Circle c1 = new Circle();
		System.out.println(c1.toString());

		Cylinder cy1 = new Cylinder();
		System.out.println(cy1.toString());

		Cylinder cy2 = new Cylinder(c1, 5);
		System.out.println(cy2.toString());

		c1 = new Circle(5);
		System.out.println(c1.toString());

		cy1 = new Cylinder(5, 10);
		System.out.println(cy1.toString());

		cy2 = new Cylinder(c1,10);
		System.out.println(cy2.toString());
	}
}
