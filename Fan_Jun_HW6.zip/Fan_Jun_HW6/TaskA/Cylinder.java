package subclass;
import superclass.Circle;
public class Cylinder extends Circle {
	private float height;
	
	public Cylinder() {
		super(0);
		height = 0;
	}
	
	public Cylinder(double new_radius, float new_height) {
		super(new_radius);
		this.setHeight(new_height);
	}
	
	public Cylinder(Circle new_c, float new_height) {
		super(new_c.getRadius());
		this.setHeight(new_height);
	}
	
	public float getHeight() {
		return this.height;
	}
	
	public void setHeight(float height) {
		this.height = height;
	}
	
	public float calcVol() {
		super.calcArea();
		float volume;
		volume = (float) (calcArea() * this.height);
		return volume;
	}
	
	public String toString() {
		String ret;
		ret = super.toString();
		ret = ret + "\n" + "Height: " + this.height;
		ret = ret + "\n" + "Volume: " + this.calcVol();
		return ret;
	}
	
	
}
